import React from 'react'
import '../style/overview.scss'
function OverView() {
  return (
    <div className='overview'>
    <div className='overview__text'>
    <h1>כי הבריאות שלכם חשובה לנו !</h1>
    <h5> אישית לכל מטרה, בעיות רפואיות, ויעדים שונים תוך כדי מקצועיות, הקשבה, הנאה באימונים</h5>
    <h5> אישית לכל מטרה, בעיות רפואיות, ויעדים שונים תוך כדי מקצועיות, הקשבה, הנאה באימונים אישית לכל מטרה, בעיות רפואיות, ויעדים שונים תוך כדי מקצועיות, הקשבה, הנאה באימונים</h5>
    <h5> אישית לכל מטרה, בעיות רפואיות, ויעדים שונים תוך כדי מקצועיות, הקשבה, הנאה באימונים</h5>
    <button className=''> המטרות שלכם</button>
    </div>
    </div>
  )
}

export default OverView